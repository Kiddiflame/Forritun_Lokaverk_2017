﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FOR_Lokaverkefni_2017
{
    public class Stodhestaspil: Spilastokkar
    {
        /*Stodhestaspil erfir reglurnar frá spilastokkar en inniheldur sér spilin og statta*/

        private double aðaleinkunn;
        private int afkvæmi;
        private int strangarmál;
        private int kynbótamat;

        public double Aðaleinkunn
        {
            get
            {
                return aðaleinkunn;
            }

            set
            {
                aðaleinkunn = value;
            }
        }

        public int Afkvæmi
        {
            get
            {
                return afkvæmi;
            }

            set
            {
                afkvæmi = value;
            }
        }

        public int Strangarmál
        {
            get
            {
                return strangarmál;
            }

            set
            {
                strangarmál = value;
            }
        }

        public int Kynbótamat
        {
            get
            {
                return kynbótamat;
            }

            set
            {
                kynbótamat = value;
            }
        }

        
        public Stodhestaspil(double aðaleinkunn, int afkvæmi, int strangarmál, int kynbótamat)
        {
            Aðaleinkunn = aðaleinkunn;
            Afkvæmi = afkvæmi;
            Strangarmál = strangarmál;
            Kynbótamat = kynbótamat;
        }
    }
}
