﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FOR_Lokaverkefni_2017
{
    public class Hrutaspil: Spilastokkar
    {
        /*Hrutaspil erfir reglurnar frá spilastokkar en inniheldur sér spilin og statta*/

        private int mjólkmagn;
        private int mjólkbragð;
        private int leiklyndi;
        private int félagsskapur;
        private int fótstyrkur;
        private int kynbótamat;
        private int kjötmagn;
        private int halastyrkur;


        public int Mjólkmagn
        {
            get
            {
                return mjólkmagn;
            }

            set
            {
                mjólkmagn = value;
            }
        }

        public int Mjólkbragð
        {
            get
            {
                return mjólkbragð;
            }

            set
            {
                mjólkbragð = value;
            }
        }

        public int Leiklyndi
        {
            get
            {
                return leiklyndi;
            }

            set
            {
                leiklyndi = value;
            }
        }


        public int Félagsskapur
        {
            get
            {
                return félagsskapur;
            }

            set
            {
                félagsskapur = value;
            }
        }

        public int Fótstyrkur
        {
            get
            {
                return fótstyrkur;
            }

            set
            {
                fótstyrkur = value;
            }
        }

        public int Kynbótamat
        {
            get
            {
                return kynbótamat;
            }

            set
            {
                kynbótamat = value;
            }
        }

        public int Kjötmagn
        {
            get
            {
                return kjötmagn;
            }

            set
            {
                kjötmagn = value;
            }
        }

        public int Halastyrkur
        {
            get
            {
                return halastyrkur;
            }

            set
            {
                halastyrkur = value;
            }
        }


        public Hrutaspil(int mjólkmagn, int mjólkbragð, int leiklyndi, int félagsskapur, int fótstyrkur, int kynbótamat, int kjötmagn, int halastyrkur)
        {
            Mjólkmagn = mjólkmagn;
            Mjólkbragð = mjólkbragð;
            Leiklyndi = leiklyndi;
            Félagsskapur = félagsskapur;
            Fótstyrkur = fótstyrkur;
            Kynbótamat = kynbótamat;
            Kjötmagn = kjötmagn;
            Halastyrkur = halastyrkur;
        }


    }
}
