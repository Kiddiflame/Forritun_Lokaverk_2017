﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FOR_Lokaverkefni_2017
{
    public class Spilastokkar
    {
        /*Geymir grunnspilastokka, allir stokkar eru 30 spil, öll spil hafa stattanna sem fylgja þeim, hafa random function svo hægt sé að draga spil almennilega, hendir eru 5 spil samtals*/
        //Grunnur fyrir clasanna
        //Hrutaspil hrutaspil = new Hrutaspil
        //Stodhestaspil stodhestar = new Stodhestaspil
    }
}
